import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'forgetpassword.dart';
import 'registerpage.dart';
import 'predictpage.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class LoginPage  extends StatefulWidget  {
  @override
  _LoginPageState createState() => _LoginPageState();
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HomePricePredictor',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        textTheme: GoogleFonts.poppinsTextTheme(),
      ),
      home: LoginPage(),
    );
  }
}

class _LoginPageState extends State<LoginPage> {
  final emailController =TextEditingController();
  final passwordController =TextEditingController();
  String? sessionCookie;
  
  Future<void> login() async {
  final url = Uri.parse('http://192.168.100.2:8002/login'); // Change for deployment
  final response = await http.post(
    url,
    headers: {'Content-Type': 'application/json'},
    body: jsonEncode({
      'email': emailController.text,
      'password': passwordController.text,
    }),
    
  );

  if (response.statusCode == 200) {
    // final responseData = jsonDecode(response.body);
    // print('Login successful: $responseData');
    final setCookie = response.headers['set-cookie'];
    if (setCookie != null) {
      // Store only the session ID part
      sessionCookie = setCookie.split(';').first;
    }

    print('Login successful, session: $sessionCookie');
    Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => HomePriceFormPage(),
                  ),
                );


  } else {
    // Parse the error message from backend
    String errorMessage = "Login failed";
    try {
      final errorData = jsonDecode(response.body);
      if (errorData['detail'] != null) {
        errorMessage = errorData['detail'];
      }
    } catch (e) {
      print('Exception caught: $e');
    }

    // Show error message in a dialog/snackbar
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Login Error"),
        content: Text(errorMessage),
        actions: [
          TextButton(
            child: Text("OK"),
            onPressed: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }
}
  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 992;

    return Scaffold(
      backgroundColor: Color(0xFFF8F9FA),
      body: Center(
        child: Container(
          constraints: BoxConstraints(maxWidth: 1200),
          height: isMobile ? null : 600,
          margin: EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 25,
                offset: Offset(0, 10),
              )
            ],
          ),
          child: isMobile
              ? _buildLeftPanel(context)
              : Row(
                  children: [
                    Expanded(child: _buildLeftPanel(context)),
                    Expanded(child: _buildRightPanel()),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _buildLeftPanel(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(40),
      child: SingleChildScrollView(
        child: Column(
          children: [
            Row(
              children: [
                Image.network(
                  'https://cdn-icons-png.flaticon.com/512/1040/1040993.png',
                  width: 40,
                  height: 40,
                ),
                SizedBox(width: 10),
                Text(
                  'HomePricePredictor',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF3B82F6),
                  ),
                ),
              ],
            ),
            SizedBox(height: 40),
            Text(
              'Welcome Back',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              'Sign in to access your account',
              style: TextStyle(color: Colors.grey[600]),
            ),
            SizedBox(height: 30),
            TextField(controller: emailController, decoration: InputDecoration(
                labelText: 'Email Address',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),),
            SizedBox(height: 20),
            TextField(controller: passwordController, decoration: InputDecoration(
                labelText: 'Password',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ), obscureText: true),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  
                ),
                TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ForgotPasswordPage(),
                      ),
                    );
                  },
                  child: Text('Forgot password?'),
                )
              ],
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                login(); // Call the login function when button is pressed
                
              },
              style: ElevatedButton.styleFrom(
                minimumSize: Size(double.infinity, 50),
                backgroundColor: Color(0xFF3B82F6),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: Text('Sign In'),
            ),
            Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
            Text("Don't have an account? "),
            TextButton(
            onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => RegisterPage(),
                  ),
                );
            },
            child: Text(
            'Sign up',
             style: TextStyle(color: Color(0xFF3B82F6)), // Same color as before
        ),
    ),
  ],
)
          ],
        ),
      ),
    );
  }

  Widget _buildRightPanel() {
    return Stack(
      fit: StackFit.expand,
      children: [
        Image.network(
          'https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1773&q=80',
          fit: BoxFit.cover,
        ),
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color(0xCC1E3A8A),
                Color(0xB62563EB),
              ],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
          ),
        ),
        Center(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 40),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "Find Your Home's True Value",
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 15),
                Text(
                  'Get accurate predictions based on market trends and property details',
                  style: TextStyle(fontSize: 18, color: Colors.white),
                  textAlign: TextAlign.center,
                )
              ],
            ),
          ),
        )
      ],
    );
  }
}
