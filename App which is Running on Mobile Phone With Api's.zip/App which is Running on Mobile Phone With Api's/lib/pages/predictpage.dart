import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'loginpage.dart';

class HomePriceFormPage extends StatefulWidget {
  @override
  _HomePriceFormPageState createState() => _HomePriceFormPageState();
}

class _HomePriceFormPageState extends State<HomePriceFormPage> {
  final TextEditingController homeTypeController = TextEditingController();
  final TextEditingController locationController = TextEditingController();
  final TextEditingController squareFeetController = TextEditingController();
  final TextEditingController bedroomsController = TextEditingController();
  final TextEditingController washroomsController = TextEditingController();
  final TextEditingController parkingController = TextEditingController();
  final TextEditingController yearController = TextEditingController();
  String?sessionCookie;
  String purpose = 'for sale'; // Default dropdown value
  Future<void> predict() async {
  final url = Uri.parse('http://192.168.100.2:8002/predict'); // Change for deployment
  final response = await http.post(
    url,
    headers: {'Content-Type': 'application/json'},
    body: jsonEncode({
  'Purpose': purpose.toLowerCase(),   // uppercase P
  'home': homeTypeController.text,
  'Location': locationController.text,
  'Size': double.tryParse(squareFeetController.text) ?? 0,
  'Parking': int.tryParse(parkingController.text) ?? 0,
  'Bedrooms': int.tryParse(bedroomsController.text) ?? 0,
  'Washrooms': int.tryParse(washroomsController.text) ?? 0,
  'Built_in_Year': int.tryParse(yearController.text) ?? 0,
}),
  );

  if (response.statusCode == 200) {
    final responseData = jsonDecode(response.body);
    print('PRICE PREDICTED: $responseData');

    // Extract predicted price - adjust the key name as per your API response
    final predictedPrice = responseData["estimated_price"];

    // Show predicted price in dialog
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Prediction Result"),
        content: Text("Estimated Price: $predictedPrice"),
        actions: [
          TextButton(
            child: const Text("OK"),
            onPressed: () => Navigator.pop(context),
          ),
        ],
      ),
    );

  } else {
    // Parse the error message from backend
    String errorMessage = "Prediction failed";
    try {
      final errorData = jsonDecode(response.body);
      if (errorData['detail'] != null) {
        errorMessage = errorData['detail'];
      }
    } catch (e) {
      print('Exception caught: $e');
    }

    // Show error message in a dialog
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Prediction Error"),
        content: Text(errorMessage),
        actions: [
          TextButton(
            child: const Text("OK"),
            onPressed: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }
}




 Future<void> logout() async {
  final url = Uri.parse('http://192.168.100.2:8002/logout');

  final response = await http.get(
    url,
    headers: {
      'Content-Type': 'application/json',
      if (sessionCookie != null) 'Cookie': sessionCookie!,
    },
  );

  if (response.statusCode == 200) {
    final responseData = jsonDecode(response.body);
    print('Logout successful: $responseData');
    Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => LoginPage()),
                          );
  } else {
    String errorMessage = "Logout failed";
    try {
      final errorData = jsonDecode(response.body);
      if (errorData['detail'] != null) {
        errorMessage = errorData['detail'];
      }
    } catch (e) {
      print('Exception caught: $e');
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Logout Error"),
        content: Text(errorMessage),
        actions: [
          TextButton(
            child: const Text("OK"),
            onPressed: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }
}



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: NetworkImage(
                  'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&q=80',
                ),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Container(color: Colors.black.withOpacity(0.4)),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  IconButton(
                    icon: const Icon(Icons.logout, color: Colors.white),
                    tooltip: 'Logout',
                    onPressed: () {
                      logout();
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Logout tapped')),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                  child: Container(
                    constraints: const BoxConstraints(maxWidth: 600),
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.95),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      children: [
                        const Text(
                          'Home Price Prediction',
                          style: TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF2D3748),
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 10),
                        const Text(
                          'Find the estimated value of your dream home',
                          style: TextStyle(
                            fontSize: 16,
                            color: Color(0xFF718096),
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 25),

                        // Dropdown for Sale/Rent
                        Padding(
                          padding: const EdgeInsets.only(bottom: 16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Purpose',
                                style: TextStyle(
                                  color: Color(0xFF4A5568),
                                  fontWeight: FontWeight.w500,
                                  fontSize: 15,
                                ),
                              ),
                              const SizedBox(height: 6),
                              DropdownButtonFormField<String>(
                                value: purpose,
                                decoration: InputDecoration(
                                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  filled: true,
                                  fillColor: Colors.white.withOpacity(0.9),
                                ),
                                items: ['for sale', 'for rent'].map((String value) {
                                  return DropdownMenuItem<String>(
                                    value: value,
                                    child: Text(value),
                                  );
                                }).toList(),
                                onChanged: (newValue) {
                                  setState(() {
                                    purpose = newValue!;
                                  });
                                },
                              ),
                            ],
                          ),
                        ),

                        _buildTextField('Home Type', 'Enter type (e.g., House,Farm House,Lower Portion,Upper Portion, Flat)', homeTypeController),
                        _buildTextField('Location', 'Enter location (e.g., F-7, Islamabad, Islamabad Capital)', locationController),
                        _buildTextField('Square Feet', 'Enter total square feet ', squareFeetController, isNumber: true),
                        _buildTextField('Parking Spaces', 'e.g. 1', parkingController, isNumber: true),
                        Row(
                          children: [
                            Expanded(
                              child: _buildTextField('Bedrooms', 'e.g. 3', bedroomsController, isNumber: true),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: _buildTextField('Washrooms', 'e.g. 2', washroomsController, isNumber: true),
                            ),
                          ],
                        ),
                        _buildTextField('Build in Year', 'e.g. 2010', yearController, isNumber: true),

                        const SizedBox(height: 20),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () {
                              predict();
                            },
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              backgroundColor: const Color(0xFF3B82F6),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              textStyle: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            child: const Text('Calculate Price'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(String label, String hint, TextEditingController controller, {bool isNumber = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(
                color: Color(0xFF4A5568),
                fontWeight: FontWeight.w500,
                fontSize: 15,
              )),
          const SizedBox(height: 6),
          TextField(
            controller: controller,
            keyboardType: isNumber ? TextInputType.number : TextInputType.text,
            decoration: InputDecoration(
              hintText: hint,
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              filled: true,
              fillColor: Colors.white.withOpacity(0.9),
              enabledBorder: OutlineInputBorder(
                borderSide: const BorderSide(color: Color(0xFFE2E8F0), width: 1.8),
                borderRadius: BorderRadius.circular(10),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: const BorderSide(color: Color(0xFF4299E1), width: 2),
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
