import 'package:flutter/material.dart';
import 'loginpage.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class VerificationPage extends StatefulWidget{
  const VerificationPage({super.key});
  @override
  State<VerificationPage> createState() => _VerificationPage();

}

class _VerificationPage extends State<VerificationPage> {   
  final verificationcode = TextEditingController();
  Future<void> verify() async {
  final url = Uri.parse('http://192.168.100.2:8002/verification'); // Change for deployment
  final response = await http.post(
    url,
    headers: {'Content-Type': 'text/plain'},
    body: verificationcode.text,
  );

  String title;
  String message;

  try {
    final data = jsonDecode(response.body);
    message = data.toString(); // Show raw data, or extract specific fields
  } catch (e) {
    message = response.body; // Show plain body if not JSON
  }

  if (response.statusCode == 200) {
    title = 'Verified';
  } else if (response.statusCode == 204) {
    title = 'Password Updated';
  } else {
    title = 'Error ${response.statusCode}';
  }

  showDialog(
    context: context,
    builder: (context) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(
          child: Text("OK"),
          onPressed: () => Navigator.pop(context),
        ),
      ],
    ),
  );
}

  Widget _buildVerificationBox(TextEditingController controller) {
    return SizedBox(
      width: 50,
      child: TextField(
        controller: controller,
        maxLength: 1,
        textAlign: TextAlign.center,
        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        decoration: const InputDecoration(
          counterText: '',
          contentPadding: EdgeInsets.symmetric(vertical: 14),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(8)),
            borderSide: BorderSide(color: Color(0xFFD1D5DB)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(8)),
            borderSide: BorderSide(color: Color(0xFF3B82F6)),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      body: Center(
        child: Container(
          constraints: const BoxConstraints(maxWidth: 1200),
          height: 600,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 25)],
          ),
          child: Row(
            children: [
              // Left side
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(40),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Logo
                      Row(
                        children: [
                          Image.network(
                            'https://cdn-icons-png.flaticon.com/512/1040/1040993.png',
                            width: 40,
                            height: 40,
                          ),
                          const SizedBox(width: 10),
                          const Text(
                            'HomePricePredictor',
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                                color: Color(0xFF3B82F6)),
                          ),
                        ],
                      ),
                      const SizedBox(height: 40),
                      // Title & subtitle
                      const Text(
                        'Verification Code',
                        style: TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF1F2937)),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        'Enter the 6-digit code sent to your email',
                        style: TextStyle(color: Color(0xFF6B7280)),
                      ),
                      const SizedBox(height: 30),
                      // Input fields
                      Form(
                        child: Column(
                          children: [
                            SizedBox(height: 30),
                            TextField(controller:verificationcode,decoration: InputDecoration(
                            labelText: 'Enter Verification Code :',
                            border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            ),
                            ),),
                            const SizedBox(height: 20),
                            
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton(
                                onPressed: () {
                                  verify();
                                },
                                style: ElevatedButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 16),
                                  backgroundColor: const Color(0xFF3B82F6),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                                child: const Text(
                                  'Verify',
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Center(
  child: Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Text("Back to Login Page"),
      TextButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => LoginPage(),
            ),
          );
        },
        child: Text(
          'Log In',
          style: TextStyle(color: Color(0xFF3B82F6)),
        ),
      ),
    ],
  ),
)

                    ],
                  ),
                ),
              ),
              // Right side image
              if (MediaQuery.of(context).size.width > 992)
                Expanded(
                  child: Stack(
                    children: [
                      Container(
                        decoration: const BoxDecoration(
                          image: DecorationImage(
                            image: NetworkImage(
                                'https://images.unsplash.com/photo-1570129477492-45c003edd2be?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1770&q=80'),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      Container(
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Color.fromRGBO(30, 58, 138, 0.8),
                              Color.fromRGBO(37, 99, 235, 0.7)
                            ],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ),
                        ),
                      ),
                      Center(
                        child: Padding(
                          padding: const EdgeInsets.all(40),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: const [
                              Text(
                                'Almost There!',
                                style: TextStyle(
                                  fontSize: 32,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white,
                                ),
                              ),
                              SizedBox(height: 15),
                              Text(
                                'Verify your account to access all features',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
