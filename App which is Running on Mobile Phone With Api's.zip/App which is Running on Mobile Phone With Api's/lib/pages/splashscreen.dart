import 'dart:async';
import 'package:flutter/material.dart';
import 'landingpage.dart';


class SplashScreen extends StatefulWidget {
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
  late final AnimationController _iconPulseController;
  late final AnimationController _bgSlideController;
  late final Animation<double> _glowAnimation;
  late final Animation<Offset> _bgSlideAnimation;

  String fullText = "HomePricePredictor";
  String displayedText = "";
  int _textIndex = 0;

  @override
  void initState() {
    super.initState();

    // Icon pulse animation
    _iconPulseController = AnimationController(
      vsync: this,
      duration: Duration(seconds: 2),
    )..repeat(reverse: true);

    _glowAnimation = Tween<double>(begin: 1.0, end: 1.15).animate(
      CurvedAnimation(parent: _iconPulseController, curve: Curves.easeInOut),
    );

    // Background slide animation
    _bgSlideController = AnimationController(
      vsync: this,
      duration: Duration(seconds: 2),
    )..forward();

    _bgSlideAnimation = Tween<Offset>(
      begin: Offset(0, 1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _bgSlideController,
      curve: Curves.easeOutBack,
    ));

    // Typewriter effect for text
    Timer.periodic(Duration(milliseconds: 100), (timer) {
      if (_textIndex < fullText.length) {
        setState(() {
          displayedText += fullText[_textIndex];
          _textIndex++;
        });
      } else {
        timer.cancel();
      }
    });

    // Navigate after 5 seconds
    Timer(Duration(seconds: 4), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => LandingPage()),
      );
    });
  }

  @override
  void dispose() {
    _iconPulseController.dispose();
    _bgSlideController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background Image
          Positioned.fill(
            child: Image.network(
              'https://images.unsplash.com/photo-1570129477492-45c003edd2be?auto=format&fit=crop&w=1770&q=80',
              fit: BoxFit.cover,
            ),
          ),

          // Overlay Slide
          SlideTransition(
            position: _bgSlideAnimation,
            child: Container(
              color: Colors.black.withOpacity(0.5),
            ),
          ),

          // Centered Content
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ScaleTransition(
                  scale: _glowAnimation,
                  child: Image.network(
                    'https://cdn-icons-png.flaticon.com/512/1040/1040993.png',
                    width: 90,
                    height: 90,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 20),
                Text(
                  displayedText,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
